from django.db import models

# Create your models here.
class Students(models.Model):
    name = models.CharField(max_length=250,unique=True)
    id = models.IntegerField(primary_key=True)

    class Meta:
        ordering = ('name',)
        verbose_name = 'student'
        verbose_name_plural = 'students'

    def __str__(self):
        return '{}'.format(self.name)