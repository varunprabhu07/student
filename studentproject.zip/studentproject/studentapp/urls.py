from django.urls import path
from .import views


urlpatterns = [
    path('', views.add, name='add'),
    path('delete/<int:id>/', views.delete, name='delete'),
    path('update/<int:id>/', views.update, name='update'),
    path('cbvhome/', views.StudentListView.as_view(), name='cbvhome'),
    path('cbvupdate/<int:pk>/', views.StudentUpdateView.as_view(), name='cbvupdate'),
    path('cbvdelete/<int:pk>/', views.StudentDeleteView.as_view(), name='cbvdelete'),
]