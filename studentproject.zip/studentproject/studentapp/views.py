from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from .forms import StudentForm
from .models import Students
from django.views.generic import ListView
from django.views.generic.edit import UpdateView,DeleteView


class StudentDeleteView(DeleteView):
    model = Students
    template_name = 'delete.html'
    success_url = reverse_lazy('cbvhome')

class StudentUpdateView(UpdateView):
    model = Students
    template_name = 'update.html'
    context_object_name = 'student'
    fields = ('name')

    def get_success_url(self):
        return reverse_lazy('cbvdetail',kwargs={'pk':self.object.id})

class StudentListView(ListView):
    model = Students
    template_name = 'home.html'
    context_object_name = 'student1'

def add(request):
    student1=Students.objects.all()
    if request.method == 'POST':
        name=request.POST.get('name','')
        student=Students(name=name)
        student.save()
    return render(request,'home.html',{'student1':student1})

def delete(request,id):
    student=Students.objects.get(id=id)
    if request.method == 'POST':
        student.delete()
        return redirect('/')
    return render(request,'delete.html')

def update(request,id):
    student=Students.objects.get(id=id)
    f=StudentForm(request.POST or None,instance=student)
    if f.is_valid():
        f.save()
        return redirect('/')
    return render(request,'edit.html',{'f':f,'student':student})





